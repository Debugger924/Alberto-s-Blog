<?php
session_start();
require 'connect.php';

// Verifica login
if (!isset($_SESSION['username'])) {
    header('Location: UTENTI/login.php');
    exit;
}

$username = $_SESSION['username'];
$error = '';
$success = false;
$serie_id = intval($_GET['serie_id'] ?? 0);

if ($serie_id <= 0) {
    header('Location: mie_recensioni.php');
    exit;
}

try {
    $pdo = connect();
    
    // Verifica che la serie appartenga all'utente
    $sql_check = "SELECT id, titolo, n_stagioni FROM serie WHERE id = :id AND user_id = :username";
    $stmt_check = $pdo->prepare($sql_check);
    $stmt_check->execute([':id' => $serie_id, ':username' => $username]);
    $serie = $stmt_check->fetch();
    
    if (!$serie) {
        header('Location: mie_recensioni.php');
        exit;
    }
} catch (PDOException $e) {
    $error = "Errore: " . $e->getMessage();
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $titolo = trim($_POST['titolo'] ?? '');
    $contenuto = trim($_POST['contenuto'] ?? '');
    $voto = intval($_POST['voto'] ?? 0);
    $stagione = !empty($_POST['stagione']) ? intval($_POST['stagione']) : NULL;

    if (empty($titolo) || empty($contenuto) || $voto < 1 || $voto > 10) {
        $error = 'Compila tutti i campi obbligatori correttamente!';
    } else {
        try {
            $pdo = connect();
            
            $sql = "INSERT INTO recensione (titolo, contenuto, voto, stagione_recensione, serie_id, user_id) 
                    VALUES (:titolo, :contenuto, :voto, :stagione, :serie_id, :user_id)";
            
            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                ':titolo' => $titolo,
                ':contenuto' => $contenuto,
                ':voto' => $voto,
                ':stagione' => $stagione,
                ':serie_id' => $serie_id,
                ':user_id' => $username
            ]);
            
            $success = true;
        } catch (PDOException $e) {
            $error = "Errore durante il salvataggio: " . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Aggiungi Recensione - SerieLog</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <div class="header-content">
            <div class="logo">🎬 SerieLog</div>
            <div class="header-right">
                <span style="margin-right: 20px;">Ciao, <?php echo htmlspecialchars($username); ?>!</span>
                <a href="UTENTI/logout.php">Logout</a>
            </div>
        </div>
    </header>

    <div class="container">
        <div class="card">
            <?php if ($success): ?>
                <div class="message success">
                    <h2>✅ Recensione aggiunta!</h2>
                    <p>La tua recensione è stata salvata con successo.</p>
                </div>
                <div class="button-group">
                    <a href="mie_recensioni.php" class="btn-primary" style="text-align:center; text-decoration:none;">Torna alle Mie Recensioni</a>
                </div>
            <?php else: ?>
                <h2>Aggiungi Recensione</h2>
                <p style="color: #666; margin-bottom: 20px;">
                    <strong><?php echo htmlspecialchars($serie['titolo']); ?></strong>
                </p>

                <?php if ($error): ?>
                    <div class="message error">
                        <p><?php echo htmlspecialchars($error); ?></p>
                    </div>
                <?php endif; ?>

                <form method="POST" action="">
                    <div class="form-group">
                        <label for="titolo">Titolo della Recensione *</label>
                        <input type="text" id="titolo" name="titolo" required 
                               value="<?php echo htmlspecialchars($_POST['titolo'] ?? ''); ?>">
                    </div>

                    <div class="form-group">
                        <label for="contenuto">Contenuto *</label>
                        <textarea id="contenuto" name="contenuto" rows="6" required 
                                  placeholder="Scrivi la tua recensione..."><?php echo htmlspecialchars($_POST['contenuto'] ?? ''); ?></textarea>
                    </div>

                    <div class="form-group">
                        <label for="voto">Voto (1-10) *</label>
                        <input type="number" id="voto" name="voto" min="1" max="10" required 
                               value="<?php echo htmlspecialchars($_POST['voto'] ?? ''); ?>">
                    </div>

                    <div class="form-group">
                        <label for="stagione">Stagione (opzionale)</label>
                        <input type="number" id="stagione" name="stagione" min="1" max="<?php echo $serie['n_stagioni']; ?>"
                               value="<?php echo htmlspecialchars($_POST['stagione'] ?? ''); ?>"
                               placeholder="Lascia vuoto se non specifico">
                    </div>

                    <div class="button-group">
                        <button type="submit" class="btn-primary">Salva Recensione</button>
                        <a href="mie_recensioni.php" class="btn-secondary" style="text-align:center; text-decoration:none;">Annulla</a>
                    </div>
                </form>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>