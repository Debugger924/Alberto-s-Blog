<?php
session_start();
require 'connect.php';

// Verifica login
if (!isset($_SESSION['username'])) {
    header('Location: UTENTI/login.php');
    exit;
}

$username = $_SESSION['username'];
$serie_id = intval($_POST['id'] ?? 0);

if ($serie_id <= 0) {
    header('Location: index.php');
    exit;
}

try {
    $pdo = connect();
    
    // Verifica che la serie appartenga all'utente
    $sql_check = "SELECT id FROM serie WHERE id = :id AND user_id = :username";
    $stmt_check = $pdo->prepare($sql_check);
    $stmt_check->execute([':id' => $serie_id, ':username' => $username]);
    
    if ($stmt_check->fetch()) {
        // Elimina la serie
        $sql = "DELETE FROM serie WHERE id = :id";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([':id' => $serie_id]);
    }
} catch (PDOException $e) {
    error_log("Errore eliminazione serie: " . $e->getMessage());
}

header('Location: index.php');
exit;