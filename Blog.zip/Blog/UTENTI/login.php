<?php
session_start();
$error = '';
require "../connect.php";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if (empty($username) || empty($password)) {
        $error = 'Compila tutti i campi!';
    } else {
        try {
            $pdo = connect();

            $sql = "SELECT username, password FROM utenti WHERE username = :username";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([':username' => $username]);
            $user = $stmt->fetch();

            //CHECK USER AND PASSWORD
            if ($user && $password === $user['password']) {
            
                $_SESSION['username'] = $user['username'];
                header('Location: ../index.php');
                exit;
            } else {
                $error = 'Username o password errati!';
            }
        } catch (PDOException $e) {
            $error = 'Errore di connessione al database!';
        }
    }
}
?>

<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - SerieLog</title>
    <link rel="stylesheet" href="../style.css">
</head>
<body>
    <header>
        <div class="header-content">
            <div class="logo">🎬 SerieLog</div>
        </div>
    </header>

    <div class="container">
        <div class="card" style="max-width: 400px; margin: 0 auto;">
            <h2>Accedi</h2>
            
            <?php if ($error): ?>
                <div class="message error">
                    <p><?php echo htmlspecialchars($error); ?></p>
                </div>
            <?php endif; ?>

            <form method="POST" action="">
                <div class="form-group">
                    <label for="username">Username</label>
                    <input type="text" id="username" name="username" required 
                           value="<?php echo htmlspecialchars($_POST['username'] ?? ''); ?>">
                </div>
                
                <div class="form-group">
                    <label for="password">Password</label>
                    <input type="password" id="password" name="password" required>
                </div>
                
                <div class="button-group">
                    <button type="submit" class="btn-primary">Accedi</button>
                </div>
            </form>
            
            <p style="text-align: center; margin-top: 16px; font-size: 14px;">
                Non hai un account? <a href="register.php">Registrati</a>
            </p>
        </div>
    </div>
</body>
</html>

