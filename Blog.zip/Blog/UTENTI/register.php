<?php

require '../connect.php';

$error = '';
$success = false;

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $username               = trim($_POST['username'] ?? '');
    $nome                   = trim($_POST['nome'] ?? '');
    $cognome                = trim($_POST['cognome'] ?? '');
    $email                  = trim($_POST['email'] ?? '');
    $password               = $_POST['password'] ?? '';
    $conferma_password      = $_POST['conferma_password'] ?? '';

    // Validazione
    if (empty($username) || empty($nome) || empty($cognome) || empty($email) || empty($password)) {
        $error = 'Compila tutti i campi obbligatori!';
    } elseif ($password !== $conferma_password) {
        $error = 'Le password non coincidono!';
    } elseif (strlen($password) < 6) {
        $error = 'La password deve essere di almeno 6 caratteri!';
    } else {

        try {
            $pdo = connect();
            
            // Verifica se username già esiste
            $sql_check = "SELECT username FROM utenti WHERE username = :username";
            $stmt_check = $pdo->prepare($sql_check);
            $stmt_check->execute([':username' => $username]);
            
            if ($stmt_check->fetch()) {
                $error = 'Username già in uso!';
            } else {
                // Verifica se email già esiste
                $sql_check_email = "SELECT username FROM utenti WHERE email = :email";
                $stmt_check_email = $pdo->prepare($sql_check_email);
                $stmt_check_email->execute([':email' => $email]);
                
                if ($stmt_check_email->fetch()) {
                    $error = 'Email già registrata!';
                } else {
                    
                    // Inserisci nuovo utente
                    $sql = "INSERT INTO utenti (username, nome, cognome, password, email) 
                            VALUES (:username, :nome, :cognome, :password, :email)";
                    
                    $stmt = $pdo->prepare($sql);
                    $stmt->execute([
                        ':username' => $username,
                        ':nome' => $nome,
                        ':cognome' => $cognome,
                        ':email' => $email,
                        ':password' => $password
                    ]);
                    
                    $success = true;
                }
            }
        } catch (PDOException $e) {
            $error = 'Errore durante la registrazione: ' . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registrazione - SerieLog</title>
    <link rel="stylesheet" href="../style.css">
</head>
<body>
    <header>
        <div class="header-content">
            <div class="logo">🎬 SerieLog</div>
        </div>
    </header>

    <div class="container">
        <div class="card" style="max-width: 400px; margin: 0 auto;">
            <?php if ($success): ?>
                <div class="message success">
                    <h2>✅ Registrazione completata!</h2>
                    <p>Ora puoi accedere al tuo account.</p>
                </div>
                <div class="button-group">
                    <a href="login.php" class="btn-primary" style="text-align:center; text-decoration:none;">Accedi</a>
                </div>
            <?php else: ?>
                <h2>Registrati</h2>
                
                <?php if ($error): ?>
                    <div class="message error">
                        <p><?php echo htmlspecialchars($error); ?></p>
                    </div>
                <?php endif; ?>

                <form method="POST" action="">
                    <div class="form-group">
                        <label for="username">Username *</label>
                        <input type="text" id="username" name="username" required 
                               value="<?php echo htmlspecialchars($_POST['username'] ?? ''); ?>">
                    </div>

                    <div class="form-group">
                        <label for="nome">Nome *</label>
                        <input type="text" id="nome" name="nome" required 
                               value="<?php echo htmlspecialchars($_POST['nome'] ?? ''); ?>">
                    </div>

                    <div class="form-group">
                        <label for="cognome">Cognome *</label>
                        <input type="text" id="cognome" name="cognome" required 
                               value="<?php echo htmlspecialchars($_POST['cognome'] ?? ''); ?>">
                    </div>
                    
                    <div class="form-group">
                        <label for="email">Email *</label>
                        <input type="email" id="email" name="email" required 
                               value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>">
                    </div>
                    
                    <div class="form-group">
                        <label for="password">Password *</label>
                        <input type="password" id="password" name="password" required minlength="6">
                    </div>

                    <div class="form-group">
                        <label for="conferma_password">Conferma Password *</label>
                        <input type="password" id="conferma_password" name="conferma_password" required>
                    </div>
                    
                    <div class="button-group">
                        <button type="submit" class="btn-primary">Registrati</button>
                    </div>
                </form>
                
                <p style="text-align: center; margin-top: 16px; font-size: 14px;">
                    Hai già un account? <a href="login.php">Accedi</a>
                </p>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>

