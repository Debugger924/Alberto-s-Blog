CREATE DATABASE dbblog
    DEFAULT CHARACTER SET = 'utf8mb4';

USE dbblog;

CREATE TABLE utenti (
    username VARCHAR(50) PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    cognome VARCHAR(100) NOT NULL,
    password VARCHAR(255) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    data_iscrizione DATETIME DEFAULT CURRENT_TIMESTAMP
);


CREATE TABLE serie (
    id INT PRIMARY KEY AUTO_INCREMENT,
    titolo VARCHAR(255) NOT NULL,
    categoria_stream VARCHAR(100),
    genere VARCHAR(100),
    anno INT,
    n_stagioni INT,
    descr_breve TEXT,
    created_data DATETIME DEFAULT CURRENT_TIMESTAMP,
    user_id VARCHAR(50),
    FOREIGN KEY (user_id) REFERENCES utenti(username) ON DELETE CASCADE
);

CREATE TABLE recensione (
    id INT PRIMARY KEY AUTO_INCREMENT,
    titolo VARCHAR(255) NOT NULL,
    contenuto TEXT NOT NULL,
    voto TINYINT UNSIGNED CHECK(voto BETWEEN 1 AND 10),
    stagione_recensione INT,
    created_data DATETIME DEFAULT CURRENT_TIMESTAMP,
    serie_id INT NOT NULL,
    user_id VARCHAR(50) NOT NULL,
    FOREIGN KEY (serie_id) REFERENCES serie(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES utenti(username) ON DELETE CASCADE
);

-- ============================================
-- POPOLAZIONE TABELLA UTENTI (10 utenti)
-- ============================================
INSERT INTO utenti (username, nome, cognome, password, email, data_iscrizione) VALUES
('mrossi', 'Mario', 'Rossi', 'pass123', 'mario.rossi@email.com', '2024-01-15 10:30:00'),
('lbianchi', 'Luca', 'Bianchi', 'luca008', 'luca.bianchi@email.com', '2024-01-20 14:15:00'),
('gverdi', 'Giulia', 'Verdi', 'pasticcino!23', 'giulia.verdi@email.com', '2024-02-01 09:45:00'),
('aferri', 'Anna', 'Ferri', 'itssecret?!', 'anna.ferri@email.com', '2024-02-05 16:20:00'),
('mmoretti', 'Marco', 'Moretti', 'marco007', 'marco.moretti@email.com', '2024-02-10 11:00:00'),
('srizzo', 'Sara', 'Rizzo', 'sara123', 'sara.rizzo@email.com', '2024-02-15 13:30:00'),
('pmarini', 'Paolo', 'Marini', 'paolo999', 'paolo.marini@email.com', '2024-02-20 10:15:00'),
('eromano', 'Elena', 'Romano', 'elena123', 'elena.romano@email.com', '2024-02-25 15:45:00'),
('fcosta', 'Francesco', 'Costa', 'fran123', 'francesco.costa@email.com', '2024-03-01 12:00:00'),
('vbrun', 'Valentina', 'Brun', 'valentina123', 'valentina.brun@email.com', '2024-03-05 14:30:00');


-- ============================================
-- POPOLAZIONE TABELLA SERIE (10 serie)
-- ============================================
INSERT INTO serie (titolo, categoria_stream, genere, anno, n_stagioni, descr_breve, user_id, created_data) VALUES
('Game of Thrones', 'HBO Max', 'Fantasy', 2011, 8, 'Una battaglia epica per il controllo dei Sette Regni con draghi, intrighi politici e personaggi indimenticabili.', 'mrossi', '2024-01-15 10:30:00'),
('Breaking Bad', 'Netflix', 'Drama', 2008, 5, 'Un professore di chimica diventa produttore di metanfetamina. Una discesa agli inferi magistralmente narrata.', 'lbianchi', '2024-01-16 11:45:00'),
('Stranger Things', 'Netflix', 'Sci-Fi', 2016, 4, 'Ragazzi in una cittadina dell''Indiana scoprono fenomeni sovrumani e governativi oscuri.', 'gverdi', '2024-01-17 09:20:00'),
('The Crown', 'Netflix', 'Drama', 2016, 5, 'La storia della Regina Elisabetta II e della famiglia reale britannica attraverso i decenni.', 'aferri', '2024-01-18 14:00:00'),
('Sherlock', 'BBC', 'Thriller', 2010, 4, 'Una moderna reinterpretazione delle storie di Sherlock Holmes ambientata a Londra contemporanea.', 'mmoretti', '2024-01-19 10:15:00'),
('The Witcher', 'Netflix', 'Fantasy', 2019, 3, 'Le avventure di Geralt di Rivia, un mutante cacciatore di mostri, in un mondo fantasy ricco di magia.', 'srizzo', '2024-01-20 13:30:00'),
('Chernobyl', 'HBO Max', 'Drama', 2019, 1, 'Il racconto del disastro nucleare di Chernobyl del 1986 attraverso gli occhi di chi lo visse.', 'pmarini', '2024-01-21 11:00:00'),
('Peaky Blinders', 'Netflix', 'Crime', 2013, 6, 'Una famiglia di gangster a Birmingham nel dopoguerra: violenza, affari illegali e redenzione.', 'eromano', '2024-01-22 15:45:00'),
('The Office', 'Amazon Prime', 'Comedy', 2005, 9, 'La vita quotidiana dei dipendenti di una carta di Dunder Mifflin: esilarante e commovente.', 'fcosta', '2024-01-23 12:30:00'),
('Succession', 'HBO Max', 'Drama', 2018, 4, 'Una famiglia miliardaria lotta per il controllo di un impero mediatico globale tra tradimenti e alleanze.', 'vbrun', '2024-01-24 10:00:00');


-- ============================================
-- POPOLAZIONE TABELLA RECENSIONE (10 recensioni)
-- ============================================
INSERT INTO recensione (titolo, contenuto, voto, stagione_recensione, created_data, serie_id, user_id) VALUES
('Capolavoro assoluto', 'Game of Thrones è una serie che ha cambiato la televisione. Perfetto sino alla stagione 6, i personaggi sono incredibili.', 9, NULL, '2024-01-25 10:30:00', 1, 'mrossi'),
('Magistrale', 'Breaking Bad è il massimo dell''eccellenza televisiva. Walter White è il miglior antagonista mai creato. Ogni episodio è perfetto.', 10, NULL, '2024-01-26 14:15:00', 2, 'lbianchi'),
('Nostalgico e avvincente', 'Stranger Things cattura perfettamente lo spirito degli anni 80. I ragazzi sono adorabili e la trama è sempre coinvolgente.', 8, 3, '2024-01-27 09:45:00', 3, 'gverdi'),
('Affascinante racconto storico', 'The Crown è incredibilmente ben fatto. La recitazione è magistrale e la narrazione storica è accurata e interessante.', 9, NULL, '2024-01-28 16:20:00', 4, 'aferri'),
('Misterioso e intelligente', 'Sherlock è una brillante rivisitazione moderna. Benedict Cumberbatch è semplicemente eccezionale nel ruolo.', 9, NULL, '2024-01-29 11:00:00', 5, 'mmoretti'),
('Fantasy epico', 'The Witcher ha una world-building incredibile. Henry Cavill è il Geralt perfetto. Non riesco a smettere di guardare!', 8, 2, '2024-01-30 13:30:00', 6, 'srizzo'),
('Straziante e potente', 'Chernobyl è devastante. Un racconto realista di una tragedia umana che tocca il cuore. Imperdibile.', 10, 1, '2024-01-31 10:15:00', 7, 'pmarini'),
('Criminalmente bravo', 'Peaky Blinders è una serie visivamente stupenda con personaggi complessi. La musica è perfetta per l''atmosfera.', 9, NULL, '2024-01-22 15:45:00', 8, 'eromano'),
('Esilarante', 'The Office è semplicemente divertente. Gli sketch del mockumentary sono geniali e i personaggi memorabili.', 8, 5, '2024-02-02 12:30:00', 9, 'fcosta'),
('Dramma familiare intenso', 'Succession è incredibilmente avvincente. Le dinamiche familiari sono realistiche e la recitazione è di alto livello.', 9, NULL, '2024-02-03 10:00:00', 10, 'vbrun');