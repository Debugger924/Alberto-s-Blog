<?php
session_start();
require 'connect.php';

// Verifica login
if (!isset($_SESSION['username'])) {
    header('Location: UTENTI/login.php');
    exit;
}

$username = $_SESSION['username'];
$message = '';
$error = '';

try {
    $pdo = connect();
    
    // Carica le serie aggiunte dall'utente con le loro recensioni
    $sql = "SELECT s.id, s.titolo, s.genere, s.n_stagioni, s.descr_breve, s.categoria_stream,
            r.id as rec_id, r.titolo as rec_titolo, r.contenuto as rec_contenuto, r.voto, 
            r.stagione_recensione
            FROM serie s
            LEFT JOIN recensione r ON s.id = r.serie_id
            WHERE s.user_id = :username AND (r.user_id = :username2 OR r.user_id IS NULL)
            ORDER BY s.created_data DESC";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute([':username' => $username, ':username2' => $username]);
    $results = $stmt->fetchAll();
    
    // Organizza i dati per serie
    $serie_con_recensioni = [];
    foreach ($results as $row) {
        $id = $row['id'];
        if (!isset($serie_con_recensioni[$id])) {
            $serie_con_recensioni[$id] = [
                'id' => $row['id'],
                'titolo' => $row['titolo'],
                'genere' => $row['genere'],
                'n_stagioni' => $row['n_stagioni'],
                'descr_breve' => $row['descr_breve'],
                'categoria_stream' => $row['categoria_stream'],
                'recensioni' => []
            ];
        }
        
        if ($row['rec_id']) {
            $serie_con_recensioni[$id]['recensioni'][] = [
                'id' => $row['rec_id'],
                'titolo' => $row['rec_titolo'],
                'contenuto' => $row['rec_contenuto'],
                'voto' => $row['voto'],
                'stagione' => $row['stagione_recensione']
            ];
        }
    }
} catch (PDOException $e) {
    $error = "Errore nel caricamento: " . $e->getMessage();
    $serie_con_recensioni = [];
}
?>

<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Le Mie Recensioni - SerieLog</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .review-section {
            background-color: #f5f5f5;
            padding: 15px;
            border-radius: 8px;
            margin-top: 15px;
        }
        
        .review-item {
            background-color: white;
            padding: 12px;
            margin-bottom: 10px;
            border-left: 4px solid #4CAF50;
            border-radius: 4px;
        }
        
        .review-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 8px;
        }
        
        .review-title {
            font-weight: bold;
            font-size: 16px;
        }
        
        .review-rating {
            background-color: #FFD700;
            padding: 4px 8px;
            border-radius: 4px;
            font-weight: bold;
        }
        
        .review-content {
            color: #333;
            margin: 8px 0;
            line-height: 1.5;
        }
        
        .review-meta {
            font-size: 12px;
            color: #666;
            margin-top: 8px;
        }
        
        .review-actions {
            display: flex;
            gap: 8px;
            margin-top: 10px;
        }
        
        .no-reviews {
            color: #999;
            font-style: italic;
            padding: 10px;
        }
        
        .add-review-btn {
            display: inline-block;
            margin-top: 10px;
        }
    </style>
</head>
<body>
    <header>
        <div class="header-content">
            <div class="logo">🎬 SerieLog</div>
            <div class="header-right">
                <span style="margin-right: 20px;">Ciao, <?php echo htmlspecialchars($username); ?>!</span>
                <a href="UTENTI/logout.php">Logout</a>
            </div>
        </div>
    </header>

    <div class="container">
        <h1>Le Mie Recensioni</h1>

        <?php if ($error): ?>
            <div class="message error">
                <p><?php echo htmlspecialchars($error); ?></p>
            </div>
        <?php endif; ?>

        <?php if ($message): ?>
            <div class="message success">
                <p><?php echo htmlspecialchars($message); ?></p>
            </div>
        <?php endif; ?>

        <div class="nav-links">
            <a href="index.php">Scopri Serie</a>
            <a href="mie_serie.php">Le Mie Serie</a>
            <a href="mie_recensioni.php" class="active">Le Mie Recensioni</a>
            
        </div>

        <?php if (!empty($serie_con_recensioni)): ?>
            <?php foreach ($serie_con_recensioni as $serie): ?>
                <div class="card">
                    <div style="display: flex; justify-content: space-between; align-items: start;">
                        <div>
                            <h2><?php echo htmlspecialchars($serie['titolo']); ?></h2>
                            <div class="serie-meta">
                                <span class="genre-badge"><?php echo htmlspecialchars($serie['genere'] ?? 'N/D'); ?></span>
                                <span><?php echo htmlspecialchars($serie['n_stagioni'] ?? 'N/D'); ?> Stagioni</span>
                                <?php if ($serie['categoria_stream']): ?>
                                    <span><?php echo htmlspecialchars($serie['categoria_stream']); ?></span>
                                <?php endif; ?>
                            </div>
                            <p style="margin-top: 10px; color: #666;">
                                <?php echo htmlspecialchars($serie['descr_breve']); ?>
                            </p>
                        </div>
                    </div>

                    <div class="review-section">
                        <h3>Le Mie Recensioni</h3>
                        
                        <?php if (!empty($serie['recensioni'])): ?>
                            <?php foreach ($serie['recensioni'] as $review): ?>
                                <div class="review-item">
                                    <div class="review-header">
                                        <span class="review-title"><?php echo htmlspecialchars($review['titolo']); ?></span>
                                        <span class="review-rating">⭐ <?php echo $review['voto']; ?>/10</span>
                                    </div>
                                    <div class="review-content">
                                        <?php echo htmlspecialchars($review['contenuto']); ?>
                                    </div>
                                    <?php if ($review['stagione']): ?>
                                        <div class="review-meta">
                                            Stagione: <?php echo $review['stagione']; ?>
                                        </div>
                                    <?php endif; ?>
                                    <div class="review-actions">
                                        <form method="POST" action="elimina_recensione.php" style="flex: 1;">
                                            <input type="hidden" name="id" value="<?php echo $review['id']; ?>">
                                            <button type="submit" class="btn-delete btn-small" style="width: 100%;" onclick="return confirm('Elimina questa recensione?')">Elimina</button>
                                        </form>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <p class="no-reviews">Nessuna recensione ancora. Aggiungi la prima!</p>
                        <?php endif; ?>

                        <a href="aggiungi_recensione.php?serie_id=<?php echo $serie['id']; ?>" class="btn-primary add-review-btn">+ Aggiungi Recensione</a>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <div class="card" style="text-align: center;">
                <p>Non hai ancora aggiunto alcuna serie.</p>
                <a href="index.php" class="btn-primary" style="display: inline-block; margin-top: 10px; text-decoration: none;">Aggiungi una Serie</a>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>