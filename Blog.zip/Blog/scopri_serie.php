<?php
session_start();
require 'connect.php';

// Verifica login
if (!isset($_SESSION['username'])) {
    header('Location: UTENTI/login.php');
    exit;
}

$username = $_SESSION['username'];
$error = '';
$serie = [];

// Carica tutte le serie
try {
    $pdo = connect();
    $sql = "SELECT * FROM serie ORDER BY created_data DESC";
    $stmt = $pdo->prepare($sql);
    $stmt->execute();
    $serie = $stmt->fetchAll();
} catch (PDOException $e) {
    $error = "Errore nel caricamento delle serie: " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Scopri Serie - SerieLog</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <div class="header-content">
            <div class="logo">🎬 SerieLog</div>
            <div class="header-right">
                <span style="margin-right: 20px;">Ciao, <?php echo htmlspecialchars($username); ?>!</span>
                <a href="UTENTI/logout.php">Logout</a>
            </div>
        </div>
    </header>

    <div class="container">
        <h1>Scopri Serie</h1>

        <?php if ($error): ?>
            <div class="message error">
                <p><?php echo htmlspecialchars($error); ?></p>
            </div>
        <?php endif; ?>

        <!-- Navigazione -->
        <div class="nav-links">
            <a href="index.php">Home</a>
            <a href="scopri_serie.php" class="active">Scopri Serie</a>
            <a href="mie_serie.php">Le Mie Serie</a>
            <a href="mie_recensioni.php">Le Mie Recensioni</a>
        </div>

        <!-- Serie Grid -->
        <div class="series-grid">
            <?php if (!empty($serie)): ?>
                <?php foreach ($serie as $s): ?>
                    <div class="serie-card">
                        <div class="serie-card-content">
                            <h3><?php echo htmlspecialchars($s['titolo']); ?></h3>
                            <div class="serie-meta">
                                <span class="genre-badge"><?php echo htmlspecialchars($s['genere'] ?? 'N/D'); ?></span>
                                <span><?php echo htmlspecialchars($s['n_stagioni'] ?? 'N/D'); ?> Stagioni</span>
                            </div>
                            <div class="serie-description">
                                <?php echo htmlspecialchars($s['descr_breve'] ?? ''); ?>
                            </div>
                            <div class="serie-actions">
                                <a href="dettaglio_serie.php?id=<?php echo $s['id']; ?>" class="btn-primary btn-small">Visualizza</a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <p>Nessuna serie disponibile.</p>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>