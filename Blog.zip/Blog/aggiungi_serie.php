<?php
session_start();
require 'connect.php';

// Verifica login
if (!isset($_SESSION['username'])) {
    header('Location: UTENTI/login.php');
    exit;
}

$username = $_SESSION['username'];
$error = '';
$success = false;
$titolo = '';

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $titolo = trim($_POST['titolo'] ?? '');
    $genere = trim($_POST['genere'] ?? '');
    $categoria_stream = trim($_POST['categoria_stream'] ?? '');
    $anno = !empty($_POST['anno']) ? intval($_POST['anno']) : null;
    $stagioni = !empty($_POST['stagioni']) ? intval($_POST['stagioni']) : null;
    $descrizione = trim($_POST['descrizione'] ?? '');

    // Validazione
    if (empty($titolo)) {
        $error = 'Compila tutti i campi obbligatori!';
    } else {
        try {
            $pdo = connect();
            
            $sql = "INSERT INTO serie (titolo, genere, categoria_stream, anno, n_stagioni, descr_breve, user_id) 
                    VALUES (:titolo, :genere, :categoria_stream, :anno, :n_stagioni, :descrizione, :user_id)";
            
            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                ':titolo' => $titolo,
                ':genere' => $genere,
                ':categoria_stream' => $categoria_stream,
                ':anno' => $anno,
                ':n_stagioni' => $stagioni,
                ':descrizione' => $descrizione,
                ':user_id' => $username
            ]);
            
            $success = true;
        } catch (PDOException $e) {
            $error = "Errore durante il salvataggio: " . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Aggiungi Serie - SerieLog</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <div class="header-content">
            <div class="logo">🎬 SerieLog</div>
            <div class="header-right">
                <span style="margin-right: 20px;">Ciao, <?php echo htmlspecialchars($username); ?>!</span>
                <a href="UTENTI/logout.php">Logout</a>
            </div>
        </div>
    </header>

    <div class="container">
        <div class="card">
            <?php if ($success): ?>
                <div class="message success">
                    <h2>✅ Serie aggiunta con successo!</h2>
                    <p><strong>Titolo:</strong> <?php echo htmlspecialchars($titolo); ?></p>
                </div>
                <div class="button-group">
                    <a href="index.php" class="btn-primary" style="text-align:center; text-decoration:none;">🏠 Torna alla Home</a>
                    <a href="mie_serie.php" class="btn-secondary" style="text-align:center; text-decoration:none;">📚 Le Mie Serie</a>
                </div>
            <?php else: ?>
                <h2>Aggiungi una Nuova Serie</h2>

                <?php if ($error): ?>
                    <div class="message error">
                        <p><?php echo htmlspecialchars($error); ?></p>
                    </div>
                <?php endif; ?>

                <form method="POST" action="">
                    <div class="form-group">
                        <label for="titolo">Titolo *</label>
                        <input type="text" id="titolo" name="titolo" required 
                               value="<?php echo htmlspecialchars($_POST['titolo'] ?? ''); ?>">
                    </div>

                    <div class="form-group">
                        <label for="genere">Genere</label>
                        <select id="genere" name="genere">
                            <option value="">Seleziona</option>
                            <option value="Drama" <?php echo ($_POST['genere'] ?? '') == 'Drama' ? 'selected' : ''; ?>>Drama</option>
                            <option value="Commedia" <?php echo ($_POST['genere'] ?? '') == 'Commedia' ? 'selected' : ''; ?>>Commedia</option>
                            <option value="Fantasy" <?php echo ($_POST['genere'] ?? '') == 'Fantasy' ? 'selected' : ''; ?>>Fantasy</option>
                            <option value="Sci-Fi" <?php echo ($_POST['genere'] ?? '') == 'Sci-Fi' ? 'selected' : ''; ?>>Sci-Fi</option>
                            <option value="Horror" <?php echo ($_POST['genere'] ?? '') == 'Horror' ? 'selected' : ''; ?>>Horror</option>
                            <option value="Crime" <?php echo ($_POST['genere'] ?? '') == 'Crime' ? 'selected' : ''; ?>>Crime</option>
                            <option value="Thriller" <?php echo ($_POST['genere'] ?? '') == 'Thriller' ? 'selected' : ''; ?>>Thriller</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="categoria_stream">Piattaforma Streaming</label>
                        <select id="categoria_stream" name="categoria_stream">
                            <option value="">Seleziona</option>
                            <option value="Netflix" <?php echo ($_POST['categoria_stream'] ?? '') == 'Netflix' ? 'selected' : ''; ?>>Netflix</option>
                            <option value="Amazon Prime" <?php echo ($_POST['categoria_stream'] ?? '') == 'Amazon Prime' ? 'selected' : ''; ?>>Amazon Prime</option>
                            <option value="Disney+" <?php echo ($_POST['categoria_stream'] ?? '') == 'Disney+' ? 'selected' : ''; ?>>Disney+</option>
                            <option value="HBO Max" <?php echo ($_POST['categoria_stream'] ?? '') == 'HBO Max' ? 'selected' : ''; ?>>HBO Max</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="anno">Anno</label>
                        <input type="number" id="anno" name="anno" min="1900" max="2026"
                               value="<?php echo htmlspecialchars($_POST['anno'] ?? ''); ?>">
                    </div>

                    <div class="form-group">
                        <label for="stagioni">Nº Stagioni</label>
                        <input type="number" id="stagioni" name="stagioni" min="1"
                               value="<?php echo htmlspecialchars($_POST['stagioni'] ?? ''); ?>">
                    </div>

                    <div class="form-group">
                        <label for="descrizione">Descrizione</label>
                        <textarea id="descrizione" name="descrizione" rows="6" 
                                  placeholder="Descrivi la serie..."><?php echo htmlspecialchars($_POST['descrizione'] ?? ''); ?></textarea>
                    </div>

                    <div class="button-group">
                        <button type="submit" class="btn-primary">Aggiungi Serie</button>
                        <a href="index.php" class="btn-secondary" style="text-align:center; text-decoration:none;">Annulla</a>
                    </div>
                </form>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>