<?php
session_start();
require 'connect.php';

// Verifica se l'utente è loggato
$isLoggedIn = isset($_SESSION['username']);
$username = $_SESSION['username'] ?? null;

// Se non loggato, mostra solo la home senza funzionalità
if (!$isLoggedIn) {
    ?>
    <!DOCTYPE html>
    <html lang="it">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>SerieLog - Blog Serie TV</title>
        <link rel="stylesheet" href="style.css">
    </head>
    <body>
        <header>
            <div class="header-content">
                <div class="logo">🎬 SerieLog</div>
                <div class="header-right">
                    <a href="UTENTI/login.php">Login</a>
                </div>
            </div>
        </header>

        <div class="container">
            <div class="card" style="text-align: center;">
                <h2>Benvenuto in SerieLog!</h2>
                <p style="font-size: 16px; margin: 20px 0;">Accedi per scoprire le serie TV, aggiungere le tue preferite e scrivere recensioni.</p>
                <div class="button-group">
                    <a href="UTENTI/login.php" class="btn-primary" style="text-decoration: none;">Accedi</a>
                    <a href="UTENTI/register.php" class="btn-secondary" style="text-decoration: none;">Registrati</a>
                </div>
            </div>

            <div class="nav-links">
                <a href="index.php" class="active">Home</a>
            </div>
        </div>
    </body>
    </html>
    <?php
    exit;
}
?>

<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SerieLog - Blog Serie TV</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <div class="header-content">
            <div class="logo">🎬 SerieLog</div>
            <div class="header-right">
                <span style="margin-right: 20px;">Ciao, <?php echo htmlspecialchars($username); ?>!</span>
                <a href="UTENTI/logout.php">Logout</a>
            </div>
        </div>
    </header>

    <div class="container">
        <!-- Aggiungi Serie -->
        <div class="card">
            <h2>Nuova Serie</h2>
            <form method="POST" action="aggiungi_serie.php">
                <div class="form-group">
                    <label>Titolo *</label>
                    <input type="text" name="titolo" required>
                </div>
                <div class="form-group">
                    <label>Genere</label>
                    <select name="genere">
                        <option value="">Seleziona</option>
                        <option value="Drama">Drama</option>
                        <option value="Commedia">Commedia</option>
                        <option value="Fantasy">Fantasy</option>
                        <option value="Sci-Fi">Sci-Fi</option>
                        <option value="Horror">Horror</option>
                        <option value="Crime">Crime</option>
                        <option value="Thriller">Thriller</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Piattaforma Streaming</label>
                    <select name="categoria_stream">
                        <option value="">Seleziona</option>
                        <option value="Netflix">Netflix</option>
                        <option value="Amazon Prime">Amazon Prime</option>
                        <option value="Disney+">Disney+</option>
                        <option value="HBO Max">HBO Max</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Anno</label>
                    <input type="number" name="anno" min="1900" max="2026">
                </div>
                <div class="form-group">
                    <label>Nº Stagioni</label>
                    <input type="number" name="stagioni" min="1">
                </div>
                <div class="form-group">
                    <label>Descrizione</label>
                    <textarea name="descrizione" placeholder="Descrivi la serie..."></textarea>
                </div>
                <div class="button-group">
                    <button type="submit" class="btn-primary">Aggiungi Serie</button>
                    <button type="reset" class="btn-secondary">Cancella</button>
                </div>
            </form>
        </div>

        <!-- Navigazione -->
        <div class="nav-links">
            <a href="index.php" class="active">Home</a>
            <a href="scopri_serie.php">Scopri Serie</a>
            <a href="mie_serie.php">Le Mie Serie</a>
            <a href="mie_recensioni.php">Le Mie Recensioni</a>
        </div>

        <!-- Benvenuto -->
        <div class="card" style="text-align: center;">
            <h2>Benvenuto in SerieLog!</h2>
            <p style="font-size: 16px; margin: 20px 0;">Qui puoi aggiungere le tue serie TV preferite e leggere le recensioni della comunità.</p>
            <div class="button-group">
                <a href="scopri_serie.php" class="btn-primary" style="text-decoration: none;">Scopri Serie</a>
                <a href="mie_serie.php" class="btn-secondary" style="text-decoration: none;">Le Mie Serie</a>
            </div>
        </div>
    </div>
</body>
</html>