<?php

function connect(){

    // credenziali di accesso al db
    $user = "alberto";
    $pass = "password123";

    $host = "localhost";
    $db = "dbblog";
    $charset = 'utf8mb4';

    $dsn = "mysql:host=$host;dbname=$db;charset=$charset";
    
    $options = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION, // Mostra gli errori come eccezioni
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,       // Recupera i risultati come array associativi
        PDO::ATTR_EMULATE_PREPARES   => false,                  // Disabilita l'emulazione delle preparazioni
    ];

    try {
        $pdo = new PDO($dsn, $user, $pass, $options);
        return $pdo;
        
        } catch (PDOException $e) {
            echo "errore di connessione al db". $e->getMessage();
        }
}
?>