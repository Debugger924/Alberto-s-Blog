<?php
session_start();
require 'connect.php';

// Verifica login
if (!isset($_SESSION['username'])) {
    header('Location: UTENTI/login.php');
    exit;
}

$username = $_SESSION['username'];
$rec_id = intval($_POST['id'] ?? 0);

if ($rec_id <= 0) {
    header('Location: mie_recensioni.php');
    exit;
}

try {
    $pdo = connect();
    
    // Verifica che la recensione appartenga all'utente
    $sql_check = "SELECT id FROM recensione WHERE id = :id AND user_id = :username";
    $stmt_check = $pdo->prepare($sql_check);
    $stmt_check->execute([':id' => $rec_id, ':username' => $username]);
    
    if ($stmt_check->fetch()) {
        // Elimina la recensione
        $sql = "DELETE FROM recensione WHERE id = :id";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([':id' => $rec_id]);
    }
} catch (PDOException $e) {
    error_log("Errore eliminazione recensione: " . $e->getMessage());
}

header('Location: mie_recensioni.php');
exit;