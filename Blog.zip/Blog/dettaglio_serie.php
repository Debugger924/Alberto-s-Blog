<?php
session_start();
require 'connect.php';

if (!isset($_SESSION['username'])) {
    header('Location: UTENTI/login.php');
    exit;
}

$username = $_SESSION['username'];
$serie_id = intval($_GET['id'] ?? 0);
$error = '';
$serie = null;
$recensioni = [];

if ($serie_id <= 0) {
    header('Location: index.php');
    exit;
}

try {
    $pdo = connect();
    
    
    $sql_serie = "SELECT id, titolo, genere, categoria_stream, anno, n_stagioni, descr_breve, user_id, created_data 
                  FROM serie 
                  WHERE id = :id";
    
    $stmt_serie = $pdo->prepare($sql_serie);
    $stmt_serie->execute([':id' => $serie_id]);
    $serie = $stmt_serie->fetch();
    
    if (!$serie) {
        $error = 'Serie non trovata.';
    } else {
        
        $sql_recensioni = "SELECT r.id, r.titolo, r.contenuto, r.voto, r.stagione_recensione, 
                                  r.created_data, u.username, u.nome, u.cognome
                           FROM recensione r
                           JOIN utenti u ON r.user_id = u.username
                           WHERE r.serie_id = :serie_id
                           ORDER BY r.created_data DESC";
        
        $stmt_recensioni = $pdo->prepare($sql_recensioni);
        $stmt_recensioni->execute([':serie_id' => $serie_id]);
        $recensioni = $stmt_recensioni->fetchAll();
    }
} catch (PDOException $e) {
    $error = "Errore nel caricamento: " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $serie ? htmlspecialchars($serie['titolo']) : 'Serie'; ?> - SerieLog</title>
    <link rel="stylesheet" href="style.css">
    <style>
/* ===== Dettaglio Serie – tema coerente con index.php ===== */

.serie-detail-header {
    background: white;
    border: 1px solid #e0e0e0;
    border-radius: 8px;
    padding: 24px;
    margin-bottom: 30px;
}

.serie-detail-header h1 {
    font-size: 28px;
    margin-bottom: 6px;
    color: #1a1a1a;
}

.serie-detail-header p {
    font-size: 14px;
    color: #666;
}

.serie-detail-content {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 30px;
    margin-bottom: 40px;
}

/* ---- Colonna info ---- */

.serie-info {
    background: white;
    border: 1px solid #e0e0e0;
    border-radius: 8px;
    padding: 20px;
}

.serie-info h3 {
    font-size: 16px;
    margin-bottom: 12px;
    color: #1a1a1a;
}

.serie-meta-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 12px;
    margin-bottom: 20px;
}

.meta-item {
    background: #f5f5f5;
    border-radius: 6px;
    padding: 12px;
    text-align: center;
}

.meta-item strong {
    display: block;
    font-size: 16px;
    color: #0084ff;
    margin-bottom: 4px;
}

.meta-item span {
    font-size: 13px;
    color: #666;
}

.autore-info {
    background: #f5f5f5;
    border-radius: 6px;
    padding: 12px;
    font-size: 13px;
    color: #404040;
}

/* ---- Descrizione ---- */

.descrizione-section {
    background: white;
    border: 1px solid #e0e0e0;
    border-radius: 8px;
    padding: 20px;
    font-size: 14px;
    line-height: 1.6;
    color: #404040;
}

/* ---- Back button ---- */

.back-btn {
    margin-bottom: 20px;
}

.back-btn a {
    display: inline-block;
    padding: 8px 14px;
    background: #f5f5f5;
    border: 1px solid #e0e0e0;
    border-radius: 6px;
    font-size: 14px;
    color: #1a1a1a;
}

.back-btn a:hover {
    background: #e8e8e8;
}

/* ---- Recensioni ---- */

.reviews-section {
    margin-top: 40px;
}

.reviews-title {
    font-size: 22px;
    margin-bottom: 20px;
    color: #1a1a1a;
}

.review-card {
    background: white;
    border: 1px solid #e0e0e0;
    border-radius: 8px;
    padding: 20px;
    margin-bottom: 20px;
}

.review-header {
    display: flex;
    justify-content: space-between;
    gap: 10px;
    margin-bottom: 10px;
    flex-wrap: wrap;
}

.review-title {
    font-size: 16px;
    font-weight: 600;
    color: #1a1a1a;
}

.review-user-info {
    font-size: 13px;
    color: #666;
}

.review-rating {
    background: #f5f5f5;
    border-radius: 20px;
    padding: 6px 12px;
    font-size: 13px;
    font-weight: 600;
}

.review-content {
    background: #fafafa;
    border-radius: 6px;
    padding: 12px;
    font-size: 14px;
    color: #404040;
    margin: 12px 0;
}

.review-meta {
    font-size: 12px;
    color: #999;
    display: flex;
    gap: 16px;
}

/* ---- Empty state ---- */

.no-reviews {
    background: #f5f5f5;
    border-radius: 8px;
    padding: 40px 20px;
    text-align: center;
    color: #999;
}

/* ---- Responsive ---- */

@media (max-width: 768px) {
    .serie-detail-content {
        grid-template-columns: 1fr;
    }

    .serie-meta-grid {
        grid-template-columns: 1fr;
    }
}
</style>

</head>
<body>
    <header>
        <div class="header-content">
            <div class="logo">🎬 SerieLog</div>
            <div class="header-right">
                <span style="margin-right: 20px;">Ciao, <?php echo htmlspecialchars($username); ?>!</span>
                <a href="UTENTI/logout.php">Logout</a>
            </div>
        </div>
    </header>

    <div class="container">
        <div class="back-btn">
            <a href="index.php">← Torna alla Home</a>
        </div>

        <?php if ($error): ?>
            <div class="message error">
                <p><?php echo htmlspecialchars($error); ?></p>
            </div>
        <?php elseif ($serie): ?>
            <!-- Header della Serie -->
            <div class="serie-detail-header">
                <h1><?php echo htmlspecialchars($serie['titolo']); ?></h1>
                <p style="margin: 10px 0 0 0; opacity: 0.9;">
                    <?php 
                    $anno = $serie['anno'] ? $serie['anno'] : 'N/D';
                    echo htmlspecialchars($anno);
                    ?>
                </p>
            </div>

            <!-- Contenuto Dettagli -->
            <div class="serie-detail-content">
                <!-- Colonna Sinistra: Informazioni -->
                <div class="serie-info">
                    <h3>Informazioni Principali</h3>
                    
                    <div class="serie-meta-grid">
                        <div class="meta-item">
                            <strong><?php echo htmlspecialchars($serie['genere'] ?? 'N/D'); ?></strong>
                            <span>Genere</span>
                        </div>
                        <div class="meta-item">
                            <strong><?php echo htmlspecialchars($serie['n_stagioni'] ?? 'N/D'); ?></strong>
                            <span>Stagioni</span>
                        </div>
                    </div>

                    <?php if ($serie['categoria_stream']): ?>
                        <h3>Disponibile su</h3>
                        <div class="meta-item" style="margin-bottom: 15px;">
                            <strong><?php echo htmlspecialchars($serie['categoria_stream']); ?></strong>
                            <span>Piattaforma</span>
                        </div>
                    <?php endif; ?>

                    <h3>Aggiunto da</h3>
                    <div class="autore-info">
                        <p><strong>Utente:</strong> <?php echo htmlspecialchars($serie['user_id']); ?></p>
                        <p><strong>Data:</strong> <?php echo date('d/m/Y H:i', strtotime($serie['created_data'])); ?></p>
                    </div>

                    <?php if ($serie['user_id'] === $username): ?>
                        <div style="margin-top: 15px;">
                            <form method="POST" action="elimina_serie.php" style="margin-bottom: 10px;">
                                <input type="hidden" name="id" value="<?php echo $serie['id']; ?>">
                                <button type="submit" class="btn-delete" style="width: 100%;" onclick="return confirm('Sei sicuro di voler eliminare questa serie?')">Elimina Serie</button>
                            </form>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- Colonna Destra: Descrizione -->
                <div>
                    <h3 style="color: #333; margin-bottom: 15px;">Descrizione</h3>
                    <div class="descrizione-section">
                        <?php echo htmlspecialchars($serie['descr_breve'] ?? 'Nessuna descrizione disponibile.'); ?>
                    </div>
                </div>
            </div>

            <!-- Sezione Recensioni -->
            <div class="reviews-section">
                <h2 class="reviews-title">
                    Recensioni 
                    <span style="font-size: 16px; color: #999;">
                        (<?php echo count($recensioni); ?>)
                    </span>
                </h2>

                <?php if (!empty($recensioni)): ?>
                    <?php foreach ($recensioni as $review): ?>
                        <div class="review-card">
                            <div class="review-header">
                                <div>
                                    <div class="review-title">
                                        <?php echo htmlspecialchars($review['titolo']); ?>
                                    </div>
                                    <div class="review-user-info">
                                        di <strong><?php echo htmlspecialchars($review['nome'] . ' ' . $review['cognome']); ?></strong>
                                        il <?php echo date('d/m/Y', strtotime($review['created_data'])); ?>
                                    </div>
                                </div>
                                <div class="review-rating">
                                    ⭐ <?php echo htmlspecialchars($review['voto']); ?>/10
                                </div>
                            </div>

                            <div class="review-content">
                                <?php echo htmlspecialchars($review['contenuto']); ?>
                            </div>

                            <div class="review-meta">
                                <?php if ($review['stagione_recensione']): ?>
                                    <span>📺 Stagione: <?php echo $review['stagione_recensione']; ?></span>
                                <?php endif; ?>
                                <span>📅 <?php echo date('d/m/Y H:i', strtotime($review['created_data'])); ?></span>
                            </div>

                            <?php if ($review['username'] === $username): ?>
                                <div class="review-actions">
                                    <a href="modifica_recensione.php?id=<?php echo $review['id']; ?>" class="btn-primary btn-small">Modifica</a>
                                    <form method="POST" action="elimina_recensione.php" style="flex: 1;">
                                        <input type="hidden" name="id" value="<?php echo $review['id']; ?>">
                                        <button type="submit" class="btn-delete btn-small" style="width: 100%;" onclick="return confirm('Elimina questa recensione?')">Elimina</button>
                                    </form>
                                </div>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="no-reviews">
                        <p>📭 Nessuna recensione ancora.</p>
                        <p style="margin-top: 10px; font-size: 14px;">
                            <a href="aggiungi_recensione.php?serie_id=<?php echo $serie_id; ?>" style="color: #667eea; text-decoration: none;">Scrivi la prima recensione →</a>
                        </p>
                    </div>
                <?php endif; ?>
            </div>

        <?php else: ?>
            <div class="message error">
                <p>Serie non trovata.</p>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>